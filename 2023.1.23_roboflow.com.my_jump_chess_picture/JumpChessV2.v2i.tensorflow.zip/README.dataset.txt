# JumpChessV2 > 2023-01-23 6:52pm
https://universe.roboflow.com/crazyjumpchess/jumpchessv2

Provided by a Roboflow user
License: CC BY 4.0

